package GKH;

public abstract class Person {
	private String SoTK;
	private String Hoten;
	private String GT;
	public String getSoTK() {
		return SoTK;
	}	
	public Person() {
		
	}
	public Person(String soTK, String hoten, String gT) {
		
		SoTK = soTK;
		Hoten = hoten;
		GT = gT;
	}
	
	public void setSoTK(String soTK) {
		SoTK = soTK;
	}
	public String getHoten() {
		return Hoten;
	}
	public void setHoten(String hoten) {
		Hoten = hoten;
	}
	public String getGT() {
		return GT;
	}
	public void setGT(String gT) {
		GT = gT;
	}
	public abstract String Khuyenmai();
	


}
