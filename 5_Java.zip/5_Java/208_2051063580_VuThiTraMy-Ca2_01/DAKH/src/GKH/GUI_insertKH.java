package GKH;

import java.awt.EventQueue;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

//import Dasach.Sach;
//import Dasach.XLSach;

import javax.swing.DefaultComboBoxModel;

public class GUI_insertKH extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	static XLKH _xlkh = new XLKH();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		_xlkh.getCon();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_insertKH frame = new GUI_insertKH();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	//load dâta
	void loadData(ResultSet rs) {
		try {
			
			ResultSetMetaData stData = (ResultSetMetaData) rs.getMetaData();
			int count = stData.getColumnCount(); 
			
			DefaultTableModel RecordTable = (DefaultTableModel)table.getModel();
			RecordTable.setRowCount(0);
			
			while (rs.next()) {
				Vector listData = new Vector();
				Khachhang _xlkh = new Khachhang(rs.getString("SoTK"), 
						rs.getString("Hoten"), 
						rs.getString("GT"), 
						rs.getString("Diachi"), 
						
						rs.getDouble("Sodu"));
				
				for (int i=1; i<=count; i++) {
					listData.add(_xlkh.getSoTK());
					listData.add(_xlkh.getHoten());
					listData.add(_xlkh.getGT());
					listData.add(_xlkh.getDiachi());
					listData.add(_xlkh.getSodu());
//					listData.add(_xlkh.Khuyenmai());
				}
				RecordTable.addRow(listData);
			}
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex);
		}
	}
	
	void loadDataEvent() {
		ResultSet rs = null;
		try {
			rs = (ResultSet) _xlkh.getKH();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		loadData(rs);
	}
	

	/**
	 * Create the frame.
	 */
	public GUI_insertKH() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 500, 450, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Quản lí khách hàng");
		lblNewLabel.setBounds(164, 10, 104, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("SoTK");
		lblNewLabel_1.setBounds(10, 42, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Hoten");
		lblNewLabel_2.setBounds(10, 83, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("GT");
		lblNewLabel_3.setBounds(235, 42, 45, 13);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Diachi");
		lblNewLabel_4.setBounds(235, 83, 45, 13);
		contentPane.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(62, 39, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(65, 80, 96, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(308, 42, 96, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(308, 80, 96, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Hà Nội", "Hải Phòng", "Nam Định"}));
		comboBox.setBounds(62, 122, 96, 21);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Thêm khách hàng");
		btnNewButton.setBounds(281, 122, 123, 21);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 181, 416, 272);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			
			},
			new String[] {
				"SoTK", "Hoten ", "GT", "Diachi", "Sodu", "Khuyenmai"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, Double.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(table);
		table.getColumnModel().getColumn(2).setPreferredWidth(83);
	}
}
