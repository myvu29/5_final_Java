package GKH;

public class Khachhang extends Person {
	private String Diachi;
	private double Sodu;
	
	public Khachhang() {
		super();
	}

	public Khachhang(String soTK, String hoten, String gT,String diachi, double sodu) {
		super(soTK, hoten,gT );
		Diachi = diachi;
		Sodu = sodu;
	}

	public String getDiachi() {
		return Diachi;
	}

	public void setDiachi(String diachi) {
		Diachi = diachi;
	}

	public double getSodu() {
		return Sodu;
	}

	public void setSodu(double sodu) {
		Sodu = sodu;
	}

	@Override
	public String Khuyenmai() {
		if(this.getGT()=="nữ") {
			return "Khuyến mại";
		}
		return "";
	}

}
