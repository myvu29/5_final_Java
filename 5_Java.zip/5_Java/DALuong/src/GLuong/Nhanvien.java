package GLuong;

public class Nhanvien extends Person {
	private String Diachi;
	private double Luong;
	public String getDiachi() {
		return Diachi;
	}
	public void setDiachi(String diachi) {
		Diachi = diachi;
	}
	public double getLuong() {
		return Luong;
	}
	public void setLuong(double luong) {
		Luong = luong;
	}
	public Nhanvien() {
		super();
	}
	public Nhanvien(int MaNV, String Hoten,String diachi, double luong) {
		super(MaNV,Hoten);
		Diachi = diachi;
		Luong = luong;
	}

	
}
