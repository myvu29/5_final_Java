package GKH;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;


public class XLKH {
//	private Connection con;
	public static Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dlkh", "root", "");
			Statement stm = con.createStatement();
			ResultSet rs = stm.executeQuery("Select * from tbkhachhang");
			while(rs.next()) {
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getDouble(5) );
			}
		}catch(Exception e) {
			System.out.print("Connect error " + e.getMessage());
		}
		return con;
	}

	public ResultSet getKH() throws SQLException {
		Connection con = getCon();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from tbKhachhang");
		return rs;
	}
	public boolean insertSP(String soTK, String hoten, String gT,String diachi, double sodu) {
		Connection con = getCon();
		String sql = "insert into tbkhachhang (soTK, hoten, gT,diachi,sodu)" + "values(?,?,?,?,?) ";
	
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, soTK);
			ps.setString(2, hoten);
			ps.setString(3, gT);
			ps.setString(4, diachi);
			ps.setDouble(5, sodu);
	        ps.executeUpdate();
	        con.close();
	        return true;
		} catch(Exception e) {
		
			e.printStackTrace();
			return false;
		}		
	}
	public static void main(String[] args) {
	
	System.out.println(getCon());
	XLKH _xlkh= new XLKH();
	//insert 
	_xlkh.insertSP("123456789","hahaha","nu","Ha noi",100);
	System.out.println("Hiển thị danh sách:");
	System.out.println(getCon());
	
//    Scanner a = new Scanner(System.in);
//    Khachhang kh = new Khachhang();
//    System.out.println("Nhap lan luot SoTK > Hoten > GT > Diachi > Sodu");
//    kh.setSoTK(a.nextLine());
//    kh.setHoten(a.nextLine());
//    kh.setGT(a.nextLine());
//    kh.setDiachi(a.nextLine());
//    kh.setSodu(a.nextDouble());

//    _xlkh.insertSP();

	}

}
