package QLCB;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Vector;

public interface ICanbo {
	public Connection getCon();
//	public ArrayList<Canbo> getCB();
	boolean insertCB(int sTK, String hoten, String gT, String diachi, int luong);
	boolean updateCB(int sTK, String hoten, String gT, String diachi, int luong);
//	public boolean deleteCB();

	ArrayList<Canbo> getCB();
	public boolean deleteCB(int sTK);
	Canbo timkiem(int sTK);
	

}
