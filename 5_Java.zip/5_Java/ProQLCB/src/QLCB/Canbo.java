package QLCB;

public class Canbo {
	private int STK; String Hoten; String GT; String Diachi; int Luong;

	public String getDiachi() {
		return Diachi;
	}

	public void setDiachi(String diachi) {
		Diachi = diachi;
	}

	public int getSTK() {
		return STK;
	}

	public void setSTK(int sTK) {
		STK = sTK;
	}

	public String getHoten() {
		return Hoten;
	}

	public void setHoten(String hoten) {
		Hoten = hoten;
	}

	public String getGT() {
		return GT;
	}

	public void setGT(String gT) {
		GT = gT;
	}

	public int getLuong() {
		return Luong;
	}

	public void setLuong(int luong) {
		Luong = luong;
	}

	public Canbo() {
		
	}

	public Canbo(int sTK, String hoten, String gT, String diachi, int luong) {
		
		STK = sTK;
		Hoten = hoten;
		GT = gT;
		Diachi = diachi;
		Luong = luong;
	}
	
}
