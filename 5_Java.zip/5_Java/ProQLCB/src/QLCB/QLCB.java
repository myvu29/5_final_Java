package QLCB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

public class QLCB implements ICanbo {

	@Override

	public Connection getCon() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =  DriverManager.getConnection("jdbc:mysql://localhost/qlcb","root","");
//			Statement stm = con.createStatement();
//			ResultSet rs = stm.executeQuery("Select * from tbcanbo");
//			while(rs.next()) {
//				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getInt(5) );
//			}
		}catch(Exception e) {
			
		}
		return con;
	}

	@Override
	public ArrayList<Canbo> getCB() {
		Connection con = getCon();
		String sql = "select * from tbCanbo";
		ArrayList<Canbo> lsCB = new ArrayList<>();
		try {
			Statement st = con.createStatement();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Canbo c = new Canbo();
				c.setSTK(rs.getInt(1));
				c.setHoten(rs.getString(2));
				c.setGT(rs.getString(3));
				c.setDiachi(rs.getString(4));
				c.setLuong(rs.getInt(5));
				lsCB.add(c);
			}
			
			
		}catch(Exception e) {
			
		}
		return lsCB;
	}

	@Override
	public boolean insertCB(int STK, String hoten, String gT, String diachi, int luong) {
		Connection con = getCon();
		String sql = "Insert into tbCanbo(STK, Hoten, GT, Diachi, Luong)"+"values(?,?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,STK);
			ps.setString(2, hoten);
			ps.setString(3, gT);
			ps.setString(4, diachi);
			ps.setInt(5, luong);
			ps.executeUpdate();
			con.close();
			return true;
			
		}catch(Exception e) {
			return false;
		}
		
	}


	@Override
	public boolean updateCB(int sTK, String hoten, String gT, String diachi, int luong) {
		Connection con = getCon();
		String sql = "update tbCanbo set hoten =?, gT =?, diachi =?, luong =? where sTK =?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, hoten);
			ps.setString(2,gT);
			ps.setString(3,diachi);
			ps.setInt(4,luong);
			ps.setInt(5, sTK);
			ps.executeUpdate();
			con.close();
			return true;
			
			
		}catch(Exception e) {
			return false;
		}
		
	}

	@Override
	public boolean deleteCB(int sTK) {
	try {
			
			Connection con = getCon();
			Statement st = con.createStatement();
			st.execute("DELETE FROM tbCanbo WHERE SoTK = " + String.valueOf(sTK));
			System.out.print("Xoas sách:");
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public Canbo timkiem(int sTK) {
		Connection con = getCon();
		String sql="select * from tbCanbo where SoTK = "+String .valueOf(sTK);
		Canbo cb=new Canbo();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			rs.next();
			cb.setSTK(rs.getInt(1));
			cb.setHoten(rs.getString(2));
			cb.setGT(rs.getString(3));
			cb.setDiachi(rs.getString(4));
			cb.setLuong(rs.getInt(5));
		
			
		}catch(Exception e) {
			return null;
		}
		return cb;
	}





}
