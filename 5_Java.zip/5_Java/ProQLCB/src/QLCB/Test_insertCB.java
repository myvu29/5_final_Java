package QLCB;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;

public class Test_insertCB {
	   public static void doInsertCB(Canbo cbcanbo) {
		 
			   QLCB qlcb = new QLCB();
	        try {
	            qlcb.insertCB(cbCanbo);
	            System.out.println("Insert thành công");
	        } catch (SQLException e) {
	            System.out.println("Insert không thành công");
	        }
	      
	    }
	public static void main(String[] args) {
		   Scanner a = new Scanner(System.in);
	        Test_insertCB CB = new Test_insertCB();
	        Canbo cbCanbo = new Canbo();
	        System.out.println("Nhap lan luot SoTK > Hoten > GT > Diachi > Luong");
	        cbCanbo.setsTK(a.nextLine());
	        cbCanbo.setHoten(a.nextLine());
	        cbCanbo.setGT(a.nextLine());
	        cbCanbo.setDiachi(a.nextLine());
	        cbCanbo.setluong(a.nextDouble());

	        CB.doInsertCB(cbCanbo);

			
	}

}
