package QLCB;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		QLCB qlcb= new QLCB();
			//getCanbo
		ArrayList<Canbo> ar = qlcb.getCB();
//		for(int i=0;i<ar.size();i++) {
//			System.out.println(ar.get(i).getSTK()+"-"+ar.get(i).getHoten()+"-"+ar.get(i).getGT()+"-"+ar.get(i).getDiachi()+"-"+ar.get(i).getLuong());
//		}
//		
		//C2
		for(Canbo a: ar) {
			System.out.println(a.getSTK()+"-"+a.getHoten()+"-"+a.getGT()+"-"+a.getDiachi()+"-"+a.getLuong());
		}
//		//insert
//		qlcb.insertCB(111,"HHHHH","nu","Ha noi",100);
		System.out.println(qlcb.updateCB(23456,"HHHHH","nu","Ha noi",100));
//		System.out.println(qlcb.deleteCB(3456));
		for(Canbo a: ar) {
			System.out.println(a.getSTK()+"-"+a.getHoten()+"-"+a.getGT()+"-"+a.getDiachi()+"-"+a.getLuong());
		}
		//Tim kiem
		Canbo s1 = qlcb.timkiem(23456);
		System.out.print(s1.getSTK()+"-"+s1.getHoten()+"-"+s1.getGT()+"-"+s1.getDiachi()+"-"+s1.getLuong());
	}

}
