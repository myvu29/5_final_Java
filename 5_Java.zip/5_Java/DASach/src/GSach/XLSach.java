package GSach;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class XLSach {
	
	//ket noi
	private Connection con;
	public static Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dlsach", "root", "");
		
			  Statement stmt = con.createStatement();
	            // get data from table 'student'
	            ResultSet rs = stmt.executeQuery("select * from tbSach");
	            // show data
	            while (rs.next()) {
	                System.out.println(rs.getInt(1) + "  " + rs.getString(2) 
	                        + "  " +rs.getInt(3)+ " "+rs.getDouble(4));
	            }
	            // close connection
//	            con.close();
		} catch (Exception e) {	
		}
		return con;
	}
//	public static void getSA() {
//		try {
//		Connection con = getCon();
//		Statement st = con.createStatement();
//		ResultSet rs = st.executeQuery("SELECT * FROM tbSach");
//		while (rs.next()) {
//            System.out.println(rs.getInt(1)+ "  " + rs.getString(2) + "  " +rs.getInt(3)+ " "+rs.getDouble(4) );
//        }
////		con.close();
//	
//	} catch (Exception e) {
//		e.printStackTrace();
//	
//	}   
//	}
	public static boolean insertClass(int MaS, String TenS, int NamXB, double GiaB) {
		Connection con = getCon();
		String sql = "insert into tbSach (MaS, TenS, NamXB,GiaB)" + "values(?,?,?.?) ";
		try {
//			Statement st = con.createStatement();
////			ResultSet rs = st.executeQuery("SELECT * FROM tbSach");
//			PreparedStatement ps = con.prepareStatement(sql);
////			ResultSet rs = ps.executeQuery();
			PreparedStatement ps = con.prepareStatement(sql,
                    Statement.RETURN_GENERATED_KEYS);
//			PreparedStatement ps = (PreparedStatement) con.prepareStatement(sql);
			ps.setInt(1, MaS);
			ps.setString(2, TenS);
			ps.setInt(3, NamXB);
			ps.setDouble(4, GiaB);
	        ps.executeUpdate();
//	      
	        return true;
		} catch(Exception e) {
			return false;
		}		
	}
	public ArrayList<Sach> getListSach(){
		//ket noi
		Connection con = getCon();
		String sql = "select * from tbSach";
		//khai bao mang
		ArrayList<Sach> lsSach = new ArrayList<>();
		try {
			Statement st = con.createStatement();
//			ResultSet rs = st.executeQuery("SELECT * FROM tbSach");
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Sach s = new Sach();
				s.setMaS(rs.getInt(1));
				s.setTenS(rs.getString(2));
				s.setNamXB(rs.getInt(3));
				s.setGiaB(rs.getDouble(4));
				lsSach.add(s);
			}
		}catch(SQLException e) {
				System.out.println(e);
			}

			return lsSach;
		}


	public static  boolean deleteSA(int NamXB) {
		try {
			Connection con = getCon();
			Statement st = con.createStatement();
//			ResultSet rs = st.executeQuery("SELECT MaS FROM tbSach");
			st.execute("DELETE FROM tbSach WHERE NamXB = " + String.valueOf(NamXB));
//			con.createStatement().execute("DELETE FROM tbSach WHERE NamXB = " + String.valueOf(NamXB));
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	public static void main(String[] args)
	{
//		getSA();
//		Xóa Sách
		Scanner input = new Scanner(System.in);
		 int a = input.nextInt();	
		 System.out.println(deleteSA(a));
		
//		 System.out.println(insertClass(1,"my",2000,37643));
		 
		 XLSach s= new XLSach();
			ArrayList<Sach> ar = s.getListSach();

//		 System.out.println(s.getListSach());
//		for(int i=0;i<ar.size();i++){
//			System.out.println(ar.get(i).getMaS());
//			System.out.println(ar.get(i).getTenS());
//			System.out.println(ar.get(i).getNamXB());
//			System.out.println(ar.get(i).getGiaB());
//		}
		 System.out.println(ar.size());
	}
	//	public Vector<Vector<String>> getSA() {
//		try {
//			Vector<Vector<String>> vs = new Vector<Vector<String>>();
//			Connection conn = getCon();
//			Statement st = conn.createStatement();
//			ResultSet rs = st.executeQuery("SELECT MaS FROM tbSach");
//			while (rs.next()) {
//				Vector<String> it = new Vector<String>();
//				it.add(String.valueOf(rs.getInt(1)));
//				it.add(rs.getString(2));
//				it.add(String.valueOf(rs.getInt(3)));
//				it.add(String.valueOf(rs.getDouble(4)));
//				vs.add(it);
//			}
//			conn.close();
//			return vs;
//		} catch (Exception e) {
//			return null;
//		}
//	}

}

