package GSach;
//import java.time.Year;

public class Sach extends Tailieu {
	private int  NamXB;
	private double GiaB;
	
	public int getNamXB() {
		return NamXB;
	}
	public void setNamXB(int namXB) {
		NamXB = namXB;
	}

	public double getGiaB() {
		return GiaB;
	}
	public void setGiaB(double giaB) {
		GiaB = giaB;
	}
	public Sach() {
		super();
		
	}
	public Sach(int maS, String tenS, int NamXB, double GiaB) {
		super(maS, tenS);
		// TODO Auto-generated constructor stub
	}
	public double Thanhtien() {
		if(NamXB<2015) {
			return GiaB*0.85;
		}else
			return GiaB*0.95;
	}	
}
