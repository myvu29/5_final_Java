package QLCB;

import java.sql.SQLException;

public class testaNguye {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		testaNguyegetcon ang = new testaNguyegetcon();
		System.out.println(ang.getCon());
			
	}

}
