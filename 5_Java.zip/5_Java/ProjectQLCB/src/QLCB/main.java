package QLCB;

public class main {

	public static void main(String[] args) {
		QLCB qlcb = new QLCB();
//		ICanbo cb = qlcb;
//		cb.getCon();
		System.out.println(qlcb.getCon());
	}

}
