package QLCB;

import java.sql.Connection;


public interface ICanbo {
	public Connection getCon();
//	public void insertCB();
}
