package QLCB;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;

public class GuiInsertCB extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuiInsertCB frame = new GuiInsertCB();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
//	public void loadData() {
//		DefaultTableModel model= new DefaultTableModel();
//		model.addColumn("id");
//		model.addColumn("name");
//	}
	/**
	 * Create the frame.
	 */
	public GuiInsertCB() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 450, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Tìm kiếm nhân viên ");
		btnNewButton.setBounds(26, 60, 131, 38);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(26, 10, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Ha Noi", "Nam DInh", "Hung Yen"}));
		comboBox.setBounds(208, 9, 96, 21);
		contentPane.add(comboBox);
		
		JButton btnNewButton_1 = new JButton("Cập nhật nhân viên ");
		btnNewButton_1.setBounds(218, 60, 123, 38);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPanetable = new JScrollPane();
		scrollPanetable.setBounds(10, 123, 416, 280);
		contentPane.add(scrollPanetable);
		
		table1 = new JTable();
		table1.setModel(new DefaultTableModel(
			new Object[][] {
				{"11", null},
			},
			new String[] {
				"ab", "name"
			}
		));
		scrollPanetable.setViewportView(table1);
//		contentPane.add(table);
//		loadData();
	}
}
