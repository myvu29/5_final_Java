package QLCB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public interface testIcanbo {

	 public static final Connection con= null;

		public static Connection getCon() {
			Connection con = null;
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost/qlcb", "root", "");
			
				  Statement stmt = con.createStatement();
		            // get data from table 'student'
		            ResultSet rs = stmt.executeQuery("select * from tbcanbo");
		            // show data
		            while (rs.next()) {
		                System.out.println(rs.getInt(1) + "  " + rs.getString(2) 
		                        + "  " +rs.getString(3)+ " "+rs.getString(4)+ " "+rs.getDouble(5));
		            }
		            // close connection
		            con.close();
//			
			
			} catch (Exception e) {
				
				
			}
			return con;
		}	
		public static void main(String[] args)
		{
			System.out.println(getCon());
//			System.out.println(getListSach());
		}
}
