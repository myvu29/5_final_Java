package Dasach;

import java.awt.EventQueue;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

//import GSach.Sach;
//import GSach.XLSach;

public class Gui_dsach extends JFrame {

	private JPanel contentPane;
	static XLSach _xlSach = new XLSach();
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		_xlSach.getCon();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui_dsach frame = new Gui_dsach();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	void loadData(ResultSet rs) {
		try {
			//Lấy ra số dòng truy vấn được từ database
			ResultSetMetaData stData = (ResultSetMetaData) rs.getMetaData();
			int count = stData.getColumnCount(); //count = 4
			
			DefaultTableModel RecordTable = (DefaultTableModel)table.getModel();
			RecordTable.setRowCount(0);
			
			while (rs.next()) {
				Vector listData = new Vector();
				Sach _sach = new Sach(rs.getInt("MaS"), 
						rs.getString("TenS"), 
						rs.getInt("NamXB"), 
						rs.getInt("GiaB"));
				
				for (int i=1; i<=count; i++) {
					listData.add(_sach.getMaS());
					listData.add(_sach.getTenS());
					listData.add(_sach.getNamXB());
					listData.add(_sach.getGiaB());
					listData.add(_sach.Thanhtien());
				}
				RecordTable.addRow(listData);
			}
		}
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, ex);
		}
	}
	
	void loadDataEvent() {
		ResultSet rs = null;
		try {
			rs = (ResultSet) _xlSach.getSA();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		loadData(rs);
	}
	

	/**
	 * Create the frame.
	 */
	public Gui_dsach() {
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				loadDataEvent();
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(10, 10, 279, 21);
		contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(318, 10, 85, 21);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 71, 416, 182);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			
			},
			new String[] {
				"MaS", "TenS", "NamXB", "GiaB", "Thanhtien"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, Integer.class, Integer.class, Double.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(table);
		table.getColumnModel().getColumn(2).setPreferredWidth(83);
	}
}
