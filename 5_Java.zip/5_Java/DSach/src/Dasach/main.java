package Dasach;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XLSach s = new XLSach();
		System.out.println(s.getCon());
		 Sach s1 = s.timkiem(1);
			System.out.print(s1.getMaS()+"-"+s1.getTenS()+"-"+s1.getNamXB()+"-"+s1.getGiaB());

			
			//getCB
			
//////		Xóa Sách
		Scanner input = new Scanner(System.in);
		 int a = input.nextInt();	
		 System.out.println(s.deleteSA(a));
			
	}

}
