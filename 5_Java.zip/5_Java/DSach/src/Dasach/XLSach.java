package Dasach;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
//
//import GSach.Sach;
//import GSach.XLSach;


public class XLSach {
	private static final char[] MaS = null;
	private Connection con;
	public Connection getCon() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/dlsach", "root", "");
		
		
		}catch(Exception e) {
			
		}
		return con;
	}
	
	
	public ResultSet getSA() throws SQLException {
		Connection _conn = getCon();
		Statement stmt = _conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from tbSach");
		return rs;
	}
	
	
	
//	public ArrayList<Sach> getSA(){
//		//ket noi
//		Connection con = getCon();
//		String sql = "select * from tbSach";
//		//khai bao mang
//		ArrayList<Sach> lsSach = new ArrayList<>();
//		System.out.println("1_Danh sachs:");
//		try {
//			Statement st = con.createStatement();
////			ResultSet rs = st.executeQuery("SELECT * FROM tbSach");
//			PreparedStatement ps = con.prepareStatement(sql);
//			ResultSet rs = ps.executeQuery();
//			while(rs.next()) {
//				Sach s = new Sach();
//				s.setMaS(rs.getInt(1));
//				s.setTenS(rs.getString(2));
//				s.setNamXB(rs.getInt(3));
//				s.setGiaB(rs.getDouble(4));
//				lsSach.add(s);
//			}
//		}catch(SQLException e) {
//				System.out.println(e);
//			}
//
//			return lsSach;
//		}
	public  boolean deleteSA(int NamXB) {
		try {
			
			Connection con = getCon();
			Statement st = con.createStatement();
			st.execute("DELETE FROM tbSach WHERE NamXB = " + String.valueOf(NamXB));
			System.out.print("Xoas sách:");
			con.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	public boolean insertClass(int MaS, String TenS, int NamXB, double GiaB) {
		Connection con = getCon();
		String sql = "insert into tbSach (MaS, TenS, NamXB,GiaB)" + "values(?,?,?,?) ";
		System.out.print(" Moi Nhap them sach");
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, MaS);
			pstmt.setString(2, TenS);
			pstmt.setInt(3, NamXB);
			pstmt.setDouble(4, GiaB);
	        pstmt.executeUpdate();
	        con.close();
	        return true;
		} catch(Exception e) {
		
			e.printStackTrace();
			return false;
		}		
	}
	public boolean updateClass(int MaS, String TenS, int NamXB, double GiaB) {
		Connection con = getCon();
		String sql = "update tbsach set TenS =? , NamXB =?,GiaB =? where MaS = ?";
			System.out.println("Update:");
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, TenS);
			pstmt.setInt(2, NamXB);
			pstmt.setDouble(3, GiaB);
			pstmt.setInt(4, MaS);
			pstmt.executeUpdate();
			con.close();
			return true;
		} catch(Exception e) {
				System.out.println(e);
			return false;
		}
	}
	//tìm kiếm 
	public Sach timkiem(int MaS){
	Connection con = getCon();
				String sql = "select * from tbSach where maS = "+String.valueOf(MaS);

				Sach s = new Sach();
			try {
//					Khong can
//					Statement st = con.createStatement();
					PreparedStatement ps = con.prepareStatement(sql);
					ResultSet rs = ps.executeQuery();
					rs.next();
					s.setMaS(rs.getInt(1));
					s.setTenS(rs.getString(2));
					s.setNamXB(rs.getInt(3));
					s.setGiaB(rs.getDouble(4));
				}
				catch(SQLException e) {
					System.out.println(e);
					return null;
				}

				return s;

	}
//	public static void main(String[] args) {
//		
////		System.out.println(getCon());
//		 XLSach s= new XLSach();
////			ArrayList<Sach> ar = s.getSA();
////
////			//insert
////			s.updateClass(3,"hao hao",200,11113);
//		//System.out.println(s.updateClass(1,"Ngin le 1 dem",2022,64.5));
//
////			s.insertClass(1,"Uyen",7,3838);
////				s.insertClass(5,"c",200,3764.3);
//			
//////			Xóa Sách
////			Scanner input = new Scanner(System.in);
////			 int a = input.nextInt();	
////			 System.out.println(deleteSA(a));
//
////		//Tim kiem
////		Sach b = new Sach();
////		Scanner input = new Scanner(System.in);
////		int c = input.nextInt();	
////		b.timkiem();
//		 Sach s1 = s.timkiem(1);
//		System.out.print(s1.getTenS()+"-"+s1.getTenS()+" "+s1.getNamXB()+" "+s1.getGiaB());
////		 System.out.println(deleteSA(a));
//
//			System.out.println(getCon());
//	}
}
